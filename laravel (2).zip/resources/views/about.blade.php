@extends('layouts.app')

@section('title', 'Halaman About')

@section('content')
    <p>Ini adalah halaman <strong>About</strong>. Dibuat dengan Laravel Blade.</p>
@endsection
