@extends('layouts.app')

@section('title', 'Halaman Home')

@section('content')
    <p>Selamat datang di halaman <strong>Home</strong>! 🎉</p>
@endsection
